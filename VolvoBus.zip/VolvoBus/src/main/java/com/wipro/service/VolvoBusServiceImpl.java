package com.wipro.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.entity.VolvoBus;
import com.wipro.repository.VolvoBusRepository;
@Service
public class VolvoBusServiceImpl implements VolvoBusService {
	@Autowired
	private VolvoBusRepository busRepository;
	@Override
	public List<VolvoBus> findAllBuses() {
		// TODO Auto-generated method stub
		return busRepository.findAll();
	}

	@Override
	public Optional<VolvoBus> findBusById(Long id) {
		// TODO Auto-generated method stub
		return busRepository.findById(id);
	}

	@Override
	public List<VolvoBus> findVolvoBusByRoute(String source, String destination) {
		// TODO Auto-generated method stub
		return busRepository.findBySourceAndDestination(source, destination);
	}

	@Override
	public VolvoBus addVolvoBus(VolvoBus bus) {
		// TODO Auto-generated method stub
		return busRepository.save(bus);
	}
	 @Override
	    public VolvoBus updateVolvoBusById(Long id, VolvoBus updatedBus) {
	        Optional<VolvoBus> existingBusOptional = busRepository.findById(id);

	        if (existingBusOptional.isPresent()) {
	            VolvoBus existingBus = existingBusOptional.get();
	            existingBus.setBusId(updatedBus.getBusId());
	            existingBus.setSource(updatedBus.getSource());
	            existingBus.setDestination(updatedBus.getDestination());
	            existingBus.setAmount(updatedBus.getAmount());

	            return busRepository.save(existingBus);
	        } else {
	            throw new RuntimeException("Bus with ID " + id + " not found");
	        }
	}

	@Override
	public void deleteVolvoBusById(Long id) {
		busRepository.deleteById(id);;
		
	}

}
