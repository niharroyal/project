package com.wipro.service;

import java.util.List;
import java.util.Optional;

import com.wipro.entity.VolvoBus;

public interface VolvoBusService {
	
	List<VolvoBus> findAllBuses();
	Optional<VolvoBus> findBusById(Long id);
	List<VolvoBus> findVolvoBusByRoute(String source, String destination);
	VolvoBus addVolvoBus(VolvoBus bus);
	VolvoBus updateVolvoBusById(Long id, VolvoBus updatedBus);
	void deleteVolvoBusById(Long id);
}
